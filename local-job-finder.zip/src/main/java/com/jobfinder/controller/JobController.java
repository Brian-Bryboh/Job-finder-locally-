package com.jobfinder.controller;

import com.jobfinder.model.Job;
import com.jobfinder.model.User;
import com.jobfinder.repository.JobRepository;
import com.jobfinder.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;

@Controller
public class JobController {
    @Autowired private JobRepository jobRepo;
    @Autowired private UserRepository userRepo;

    @GetMapping("/jobs")
    public String listJobs(Model model) {
        model.addAttribute("jobs", jobRepo.findAll());
        return "job-list";
    }

    @PostMapping("/post-job")
    public String postJob(@ModelAttribute Job job, Principal principal) {
        User employer = userRepo.findByEmail(principal.getName());
        job.setEmployer(employer);
        jobRepo.save(job);
        return "redirect:/employer/dashboard";
    }
}
