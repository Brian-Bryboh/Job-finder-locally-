package com.jobfinder.model;

import jakarta.persistence.*;

@Entity
public class User {
    @Id @GeneratedValue
    private Long id;
    private String name;
    private String email;
    private String password;
    private String role; // EMPLOYER or JOBSEEKER

    // Getters and setters
}
