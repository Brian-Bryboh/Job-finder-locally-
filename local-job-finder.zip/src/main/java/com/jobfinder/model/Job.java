package com.jobfinder.model;

import jakarta.persistence.*;

@Entity
public class Job {
    @Id @GeneratedValue
    private Long id;
    private String title;
    private String description;
    private String location;
    private String category;

    @ManyToOne
    private User employer;

    // Getters and setters
}
